# -*- coding: utf-8 -*-


from maltego_trx.entities import Phrase
from maltego_trx.transform import DiscoverableTransform
import re

class CertificateToIssuerName(DiscoverableTransform):
    
    
    """
    Lookup the Common Name(CN) of Issuer associated with SSL Cerificate.
    
    """
       
    
    @classmethod
    def create_entities(cls, request, response):
               
        issuer_name=request.getProperty("issuer_name")
       
        commonName=cls.get_commonName(issuer_name)
        response.addEntity(Phrase,commonName)
        

    @staticmethod
    
    def get_commonName(name):
         
     issuername_Fields=name.split(",")
     cn =[field for field in issuername_Fields if re.search("CN=", field)]
     cnValue=str(cn[0]).split('=')[1]
     return cnValue
    
if __name__=="__main__":
    pass
   
        
  
    