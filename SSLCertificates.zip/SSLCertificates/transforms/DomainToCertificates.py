# -*- coding: utf-8 -*-



from maltego_trx.entities import Certificate
from maltego_trx.maltego import UIM_PARTIAL
from maltego_trx.transform import DiscoverableTransform
import json
import urllib.request


class DomainToCertificates(DiscoverableTransform):
    
    
    """
    Search for the SSL Cerificates associated with the give Domain name.
    """
    
    @classmethod
    
    def create_entities(cls,request,response):
        domain=request.Value
        
        try:
            certificates=cls.get_certificates(domain)
            certificateCount=0
            if certificates:
                
                for certificate in certificates[0:3]:
                    
                    certificateCount+=1
                    entity=response.addEntity(Certificate,certificateCount)
                   
                    entity.addProperty("id", "Certificate Id", True,certificate["id"])
                    entity.addProperty("issuer_id", "Issuer Id", True,certificate["issuer_ca_id"])
                    entity.addProperty("issuer_name", "Issuer Name", True,certificate["issuer_name"])
                    entity.addProperty("common_name", "Cerificate Issued To", True,certificate["name_value"])
                    entity.addProperty("expiry_date", "Expiry Date", True,certificate["not_after"])
                    
            else:
                response.addUIMessage("No SSL certificates Found")
        except IOError:
            response.addUIMessage("An error occurred", messageType=UIM_PARTIAL) 
            
            
    @staticmethod
    
    def get_certificates(domainName):
        
        resultedCertificates={}
        crtshAPI = "https://crt.sh/?CN="+domainName+"&output=json"
        openUrl = urllib.request.urlopen(crtshAPI)   
          
        if(openUrl.getcode()==200):
            jsonData = openUrl.read()
            resultedCertificates = json.loads(jsonData)
                           
        return resultedCertificates
    
if __name__=="__main__":
   pass
        
        
        
    